<?php
session_start();
if ($_SESSION['role'] !== 'client') {
    header('Location: login.php');
    exit();
}

include 'db.php';

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Welcome, <?php echo $user['full_name']; ?></h1>
    <div class="dashboard-container">
        <div class="payout-container">
            <p>Your payout amount is: <span class="money-green">$<?php echo $user['payout_amount']; ?></span></p>
        </div>
        <div class="progress-bar">
            <div class="progress" style="width: 87%;"></div>
            <p>Your account is ready for payout.</p>
        </div>
        <div class="verification-container">
            <p class="pulse">Verification Required</p>
        </div>
        <div class="help-container">
            <p>If you need help, <a href="#">Contact your agent</a></p>
            <p><a href="#">Click here to set up your payout</a></p>
        </div>
    </div>
</body>
</html>