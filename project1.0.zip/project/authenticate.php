<?php
session_start();
include 'db.php';

$email = $_POST['email'];
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");
$stmt->execute(['email' => $email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['full_name'] = $user['full_name'];

    switch ($user['role']) {
        case 'admin':
            header('Location: admin.php');
            break;
        case 'editor':
            header('Location: editor.php');
            break;
        case 'client':
            header('Location: client.php');
            break;
    }
} else {
    echo "Invalid email or password.";
}
?>