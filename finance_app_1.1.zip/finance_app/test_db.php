<?php
require 'includes/config.php';
echo "Connected to the database successfully!";
?>