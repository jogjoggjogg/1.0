<?php
require_once '../includes/config.php';
require_role('client');

try {
    $stmt = $pdo->prepare("SELECT clients.*, users.telegram_link AS editor_telegram
                          FROM clients 
                          JOIN users ON clients.created_by = users.id
                          WHERE clients.id = ?");
    $stmt->execute([$_SESSION['client_id']]);
    $client = $stmt->fetch();
} catch(PDOException $e) {
    die("Error loading client data: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Client Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .dashboard-card {
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        .countdown {
            font-size: 2.5rem;
            font-weight: bold;
            color: #4a148c;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container py-5">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-5">
            <div>
                <h1 class="h3">Welcome, <?= htmlspecialchars($client['name']) ?></h1>
                <small class="text-muted">Account ID: <?= $client['id'] ?></small>
            </div>
            <a href="<?= $client['editor_telegram'] ?>" 
               class="btn btn-primary" 
               target="_blank">
               Contact Agent
            </a>
        </div>

        <!-- Payout Date Widget -->
        <div class="dashboard-card p-4 mb-4">
            <h3 class="mb-3">Payout Schedule</h3>
            <div class="countdown">
                <?= date('m/d/Y', strtotime($client['payout_date'])) ?>
            </div>
            <div class="progress mt-3" style="height: 8px;">
                <div class="progress-bar" 
                     style="width: <?= $client['progress'] ?>%">
                </div>
            </div>
            <small class="text-muted mt-2 d-block">
                <?= $client['progress'] ?>% of verification process completed
            </small>
        </div>

        <!-- Account Summary -->
        <div class="row g-4">
            <div class="col-md-4">
                <div class="dashboard-card p-4">
                    <h5 class="mb-3">Account Status</h5>
                    <div class="d-flex align-items-center">
                        <div class="badge bg-<?= $client['verified'] === 'yes' ? 'success' : 'warning' ?> me-3">
                            <?= ucfirst($client['verified']) ?>
                        </div>
                        <div>
                            <small class="text-muted">Verification Status</small>
                        </div>
                    </div>
                    <hr>
                    <div>
                        <small class="text-muted">Registered Email</small>
                        <div><?= htmlspecialchars($client['email']) ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="dashboard-card p-4">
                    <h5 class="mb-3">Payout Details</h5>
                    <div class="row">
                        <div class="col-6">
                            <small class="text-muted">Queue Position</small>
                            <div class="h4">#<?= $client['queue_number'] ?></div>
                        </div>
                        <div class="col-6">
                            <small class="text-muted">Estimated Amount</small>
                            <div class="h4">$<?= number_format($client['balance'], 2) ?></div>
                        </div>
                    </div>
                    <div class="mt-3">
                        <small class="text-muted">Assigned Agent</small>
                        <div><?= htmlspecialchars($client['editor_telegram']) ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>